import { Component, OnInit } from '@angular/core';
import { CovidService } from './services/covid.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent implements OnInit {
  // title = 'covid';

  global: number[];

  newConfirmed: number;
  totalConfirmed: number;
  newDeaths: number;
  totalDeaths: number;
  newRecovered: number;
  totalRecovered: number;

  constructor(private covidService: CovidService) {}

  ngOnInit(): void {
    // Listado global
    this.covidService.listGeneral().subscribe(
      (response) => {
        this.newConfirmed = response.Global.NewConfirmed;
        this.totalConfirmed = response.Global.TotalConfirmed;
        this.newDeaths = response.Global.NewDeaths;
        this.totalDeaths = response.Global.TotalDeaths;
        this.newRecovered = response.Global.NewRecovered;
        this.totalRecovered = response.Global.totalRecovered;

        this.global = [
          this.newConfirmed,
          this.totalConfirmed,
          this.newDeaths,
          this.totalDeaths,
          this.newRecovered,
          this.totalRecovered,
        ];
      },
      (error) => {
        console.log(error);
      }
    );
  }
}
