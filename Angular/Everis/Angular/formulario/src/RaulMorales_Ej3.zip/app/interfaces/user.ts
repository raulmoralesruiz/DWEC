export interface User {
  firstName?: string;
  email: string;
  terms: boolean;
}
